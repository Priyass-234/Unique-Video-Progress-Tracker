const lectures = [
  { id: 'lecture1', title: 'Introduction to React', videoUrl: '/videos/react-intro.mp4', duration: 300 },
  { id: 'lecture2', title: 'State and Props', videoUrl: '/videos/state-props.mp4', duration: 450 },
];

export default lectures;
